const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 79.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&h=500&fit=crop",
    description: "High-quality wireless headphones with noise cancellation and 30-hour battery life.",
    reviews: 234,
    rating: 4.5
  },
  {
    id: 2,
    name: "Smart Watch",
    price: 199.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop",
    description: "Feature-rich smartwatch with heart rate monitoring, GPS, and water resistance.",
    reviews: 512,
    rating: 4.7
  },
  {
    id: 3,
    name: "Running Shoes",
    price: 129.99,
    category: "Sports",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&h=500&fit=crop",
    description: "Comfortable and durable running shoes designed for all-day wear and maximum performance.",
    reviews: 342,
    rating: 4.4
  },
  {
    id: 4,
    name: "Yoga Mat",
    price: 34.99,
    category: "Sports",
    image: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=500&h=500&fit=crop",
    description: "Non-slip yoga mat with cushioning for comfortable practice sessions.",
    reviews: 189,
    rating: 4.6
  },
  {
    id: 5,
    name: "Coffee Maker",
    price: 89.99,
    category: "Home",
    image: "https://images.unsplash.com/photo-1517668808822-9ebb02ae2a0e?w=500&h=500&fit=crop",
    description: "Programmable coffee maker with thermal carafe and brew strength control.",
    reviews: 456,
    rating: 4.8
  },
  {
    id: 6,
    name: "Desk Lamp",
    price: 44.99,
    category: "Home",
    image: "https://images.unsplash.com/photo-1565636192335-14149f694f59?w=500&h=500&fit=crop",
    description: "LED desk lamp with adjustable brightness and color temperature for comfortable reading.",
    reviews: 203,
    rating: 4.3
  },
  {
    id: 7,
    name: "Backpack",
    price: 59.99,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop",
    description: "Spacious and durable backpack with multiple compartments for everyday use.",
    reviews: 378,
    rating: 4.6
  },
  {
    id: 8,
    name: "Sunglasses",
    price: 129.99,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&h=500&fit=crop",
    description: "Stylish UV-protection sunglasses with premium polarized lenses.",
    reviews: 291,
    rating: 4.5
  },
  {
    id: 9,
    name: "Portable Speaker",
    price: 69.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500&h=500&fit=crop",
    description: "Waterproof Bluetooth speaker with 12-hour battery and 360-degree sound.",
    reviews: 567,
    rating: 4.7
  },
  {
    id: 10,
    name: "Water Bottle",
    price: 24.99,
    category: "Sports",
    image: "https://images.unsplash.com/photo-1602143407151-7d406855fdf1?w=500&h=500&fit=crop",
    description: "Insulated stainless steel water bottle keeps drinks cold for 24 hours.",
    reviews: 412,
    rating: 4.8
  }
];

export default products;
